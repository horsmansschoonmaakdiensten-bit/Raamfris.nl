// Vul hier het e-mailadres in waarop je offerteaanvragen wilt ontvangen.
window.RAAMFRIS_EMAIL = 'jouw-email@voorbeeld.nl';
